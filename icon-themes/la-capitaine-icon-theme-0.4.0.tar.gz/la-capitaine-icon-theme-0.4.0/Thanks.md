### Thanks!
Thank you so much to the generous people who are helping to support this project. You guys inspire me to be my very best, and keep my development on going. Cheers all!

#### Significant contibutors
This is a list of people who have supported me with significant _code_ contributions. Cheers to them! :grin:

 * Andreas K. ([@DarkknightAK](https://github.com/darkknightak))

#### Significant donors
This is a list of people who have supported me with significant donations through [Paypal](https://paypal.me/keeferrourke) or [Patreon](https://www.patreon.com/krourke). Cheers to them! :grin:

(This list is empty!)
