#####Credits

 * The creators of El General/Antu, off which La Capitaine is based: https://github.com/fabianalexisinostroza/Antu
 * The creators of Numix icon set, the base of El General: https://github.com/numixproject/numix-icon-theme-circle
 * The creators of Emoji One, the emoji which I used in /emotes: http://emojione.com
 * The creators of the Material Design Icons project for some symbolic icons: https://materialdesignicons.com
 * The creators of Super Flat Remix, off which the folder icons are based: https://github.com/daniruiz/Super-Flat-Remix
